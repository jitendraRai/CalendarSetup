﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Graph;
using Microsoft.Identity.Client;

namespace Cal.PoC.Test
{
    //Requirement #1: - Validate each user in the Azure Active Directory.
    public class ValidateUsersExist
    {
        

        public static async Task<string> IsValidUser(string sUserEmail)
        {
            try
            {
                string sFound = string.Empty;
                string url = string.Format("https://graph.microsoft.com/v1.0/users?$filter=mail eq '{0}'", sUserEmail);
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + MasterTenantInformation.TenantAccessToken);
                HttpResponseMessage httpResponse = httpClient.GetAsync(url).Result;
                var data = await httpResponse.Content.ReadAsStringAsync();
                dynamic searlizeData = JsonConvert.DeserializeObject(data);
                sFound = Convert.ToString(searlizeData.value);

                return sFound;

            }
            catch (Exception cExp)
            {
                string sMessage = " IsValidUser() Error: " + cExp.Message;
                return sMessage;
            }
        }
    }
}
