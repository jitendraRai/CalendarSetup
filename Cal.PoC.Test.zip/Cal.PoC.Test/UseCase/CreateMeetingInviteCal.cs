﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Graph;
using Microsoft.Identity.Client;

namespace Cal.PoC.Test
{
    public class CreateMeetingInviteCal
    {

        public static async Task<string> CreateMeetingForUser(string sAttendees, string sOrganizer, string sSubjectOftheMeeting, string sStartDateTime, string sEndDateTime)
        {
            try
            {
                 string sFound = string.Empty;
                 string url = string.Format("https://graph.microsoft.com/v1.0/me/onlineMeetings");
                 var httpClient = new HttpClient();
                 httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + MasterTenantInformation.TenantAccessToken);

                bool bValidDate = true;
                string sStartDateForGraphAPI = string.Empty;
                string sEndDateForGraphAPI = string.Empty;

                // To validate the Date and value

                if (sStartDateTime.Length > 8)
                {
                    HelperStringToDateInfo StartDateForGraph = new HelperStringToDateInfo(sStartDateTime);

                    if (StartDateForGraph.sYear.Length == 0)
                    {
                        bValidDate = false;
                    }
                    else
                    {
                        //"2020-07-17T08:00:00"
                        sStartDateForGraphAPI = StartDateForGraph.sYear + "-" + StartDateForGraph.sMonth + "-" + StartDateForGraph.sDay + "T" +
                            StartDateForGraph.sHour + ":" + StartDateForGraph.sMinutes + ":" + StartDateForGraph.sSecond;
                    }

                }
                if (sEndDateTime.Length > 8)
                {

                    HelperStringToDateInfo EndDateForGraph = new HelperStringToDateInfo(sEndDateTime);

                    if (EndDateForGraph.sYear.Length == 0)
                    {
                        bValidDate = false;
                    }
                    else
                    {
                        //"2020-07-17T08:00:00"; //"2020-07-13T20:30:34.2444915-07:00"
                        sEndDateForGraphAPI = EndDateForGraph.sYear + "-" + EndDateForGraph.sMonth + "-" + EndDateForGraph.sDay + "T" +
                          EndDateForGraph.sHour + ":" + EndDateForGraph.sMinutes + ":" + EndDateForGraph.sSecond;
                    }
                }

                if (sStartDateForGraphAPI.Length < 8)
                {
                    sStartDateTime = DateTime.Parse(sStartDateForGraphAPI).ToUniversalTime().ToString();
                }
                else
                {
                    sStartDateTime = "2020-07-25T20:30:34.2444915-07:00"; //unreachable code
                }

                if (sEndDateForGraphAPI.Length < 8)
                {
                    sEndDateTime = DateTime.Parse(sEndDateForGraphAPI).ToUniversalTime().ToString(); 
                }
                else
                {
                    sEndDateTime = "2020-07-25T23:00:34.2464912-07:00"; //unreachable code
                }


                if (bValidDate)
                {


                    string content = @"{
                      'meetingType': 'scheduled',
                        'startDateTime':'" + sStartDateTime + "','endDateTime':'" +
                        sEndDateTime + "', 'subject':'" + sSubjectOftheMeeting +
                        "','participants': {'organizer': { 'upn': '" + sOrganizer + "' },'attendees': [ { 'upn': '" + sAttendees + "'}]}," +
                        "'joinWebUrl':'https://test.com'}";


                    var httpContent = new StringContent(content, Encoding.GetEncoding("utf-8"), "application/json");

                    var httpResponse = httpClient.PostAsync(url, httpContent).Result;

                    var data = await httpResponse.Content.ReadAsStringAsync();
                    var sOnlineMeetingResponse = JsonConvert.DeserializeObject<OnlineMeeting>(data);

                    if (sOnlineMeetingResponse != null)
                    {
                        HelperOutputInformation.MeetingWebURL = sOnlineMeetingResponse.JoinWebUrl;
                        HelperOutputInformation.SubjectOftheMeeting = sOnlineMeetingResponse.Subject;
                        sFound = HelperOutputInformation.MeetingWebURL;
                    }
                }
                return sFound;
            }
            catch (Exception cExp)
            {
                string sMessage = "CreateMeetingForUser() Error: " + cExp.Message;
                return sMessage;
            }
        }
    }
}