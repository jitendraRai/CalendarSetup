﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Graph;
using Microsoft.Identity.Client;
using System.Linq;
using Microsoft.Graph.Extensions;
using Microsoft.VisualBasic;

namespace Cal.PoC.Test
{
    
    public class GetScheduleInfoForTime
    {
        public static async Task<string> GetScheduleForUser(string sUserEmail, string sStartDateTime, string sEndDateTime, string sTimeZone)
        {
            try
            {
                string sFound = string.Empty;
                string url = string.Format("https://graph.microsoft.com/v1.0/me/calendar/getSchedule");
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + MasterTenantInformation.TenantAccessToken);


                string sStartDateForGraphAPI = string.Empty;
                string sEndDateForGraphAPI = string.Empty;

                bool bValidDate = true;


                // To validate the Date and value

                if (sStartDateTime.Length > 8)
                {
                    HelperStringToDateInfo StartDateForGraph = new HelperStringToDateInfo(sStartDateTime);

                    if (StartDateForGraph.sYear.Length == 0)
                    {
                        bValidDate = false;
                    }
                    else
                    {
                        sStartDateForGraphAPI = StartDateForGraph.sYear + "-" + StartDateForGraph.sMonth + "-" + StartDateForGraph.sDay + "T" +
                           StartDateForGraph.sHour + ":" + StartDateForGraph.sMinutes + ":" + StartDateForGraph.sSecond;

                    }

                }
                if (sEndDateTime.Length > 8)
                {

                    HelperStringToDateInfo EndDateForGraph = new HelperStringToDateInfo(sEndDateTime);

                    if (EndDateForGraph.sYear.Length == 0)
                    {
                        bValidDate = false;
                    }
                    else
                    {
                        
                        sEndDateForGraphAPI = EndDateForGraph.sYear + "-" + EndDateForGraph.sMonth + "-" + EndDateForGraph.sDay + "T" +
                          EndDateForGraph.sHour + ":" + EndDateForGraph.sMinutes + ":" + EndDateForGraph.sSecond;

                    }
                }
               
               
                if (sStartDateForGraphAPI.Length > 8)
                {
                    sStartDateTime = sStartDateForGraphAPI;
                }
                else
                {
                    sStartDateTime = "2020-07-13T20:30:34.2444915-07:00"; //unreachable code
                }

                if (sEndDateForGraphAPI.Length > 8)
                {
                    sEndDateTime = sEndDateForGraphAPI;
                }
                else
                {
                    sEndDateTime = "2020-07-13T23:00:34.2464912-07:00"; //unreachable code
                }

                if (sTimeZone.Length < 2)
                {
                    sTimeZone = "Pacific Standard Time";
                }

                if (bValidDate)
                {

                    string content = @"{
                            'schedules': ['" + sUserEmail + "'],'startTime': { 'dateTime': '" +
                            sStartDateTime + "','timeZone': '" + sTimeZone + "'},  'endTime':   {'dateTime': '" +
                            sEndDateTime + "','timeZone': '" + sTimeZone + "'},'availabilityViewInterval': 60}";

                    var httpContent = new StringContent(content, Encoding.GetEncoding("utf-8"), "application/json");

                    var httpResponse = httpClient.PostAsync(url, httpContent).Result;

                    var data = await httpResponse.Content.ReadAsStringAsync();
                       
                   //Used LINQ to get data
                    var result = (JsonConvert.DeserializeObject<dynamic>(data)
                                        .value[0].scheduleItems as IEnumerable<dynamic>)
                                        .Select(x => new {
                                        start = (DateTime)x.start.dateTime,
                                        end = (DateTime)x.end.dateTime,
                                        status= (string) x.status
                        }).ToList();

                    //Its empty 
                    if (result.Count == 0)
                    {
                        sFound = "Available";
                    }

                    if (result.Count == 1)
                    {
                        if (String.Compare(result[0].status, "free", true) == 0)
                        {
                            sFound = "Available";
                        }
                        //else either tentative or busy.
                    }
                   

                    //Received ScheduleInformation for the current valid user however ScheduleInformation as nested JSON Error.
                  //  var sScheduledObjectData = JsonConvert.DeserializeObject<ScheduleInformation>(data);

                    //  sFound = GetAvailableScheduleHourlyForUser(sScheduledObjectData, DateTime.Parse(sStartDateTime), DateTime.Parse(sEndDateTime));
                }

                if (sFound.Length == 0) //Not available for this period.
                {
                    return null;
                }
                else
                {
                    return sFound;
                }
            }
            catch (Exception cExp)
            {
                string sMessage = "GetScheduleForUser() Error: " + cExp.Message;
                return sMessage;
            }
        }

        //Due to Scheule object it will use in future.
        private static string GetAvailableScheduleHourlyForUser( ScheduleInformation oScheduleInfoVal, DateTime dtStartDateProvided, DateTime dtEndDateProvided)
        {
            bool bScheduled = true;
            bool bScheduledItemFound = false;
            string sAvailableTime = string.Empty;
            try
            {
                if (oScheduleInfoVal.ScheduleItems != null)
                {
                    foreach (ScheduleItem oSchedItem in oScheduleInfoVal.ScheduleItems)
                    {
                        bScheduledItemFound = true;
                        DateTime dtStartDate = oSchedItem.Start.ToDateTime();
                        DateTime dtEndDate = oSchedItem.End.ToDateTime();

                        if (DateTime.Compare(dtStartDate, dtStartDateProvided) == 0)
                        {
                            if (DateTime.Compare(dtEndDate, dtEndDateProvided) == 0)
                            {
                                if (oSchedItem.Status != FreeBusyStatus.Free)
                                {
                                    bScheduled = true;
                                }
                                else
                                {
                                    bScheduled = false;
                                }
                            }
                        }
                    }
                }
                

                if (bScheduledItemFound)
                {
                    if (bScheduled)
                    {
                        return "Available";
                    }
                    else
                    {
                        return string.Empty;
                    }
                }
                else //Scheduled item not found
                {
                    return "Available";
                }
            }
            catch (Exception cExp)
            {
                string sMessage = "GetScheduleForUser() Error: " + cExp.Message;
                return sMessage;

            }
        }
    }
}
