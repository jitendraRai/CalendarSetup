﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Graph;
using Microsoft.Identity.Client;

namespace Cal.PoC.Test
{
    // Requirement #3:- Create meeting invitations
    public class CreateEventCalendar
    {

        public static async Task<string> CreateEventCalendarForUser(string sAttendees, string sOrganizer, string sSubjectOftheMeeting, string sStartDateTime, string sEndDateTime, string sTimeZone)
        {
            try
            {
                string sFound = string.Empty;
                string url = string.Format("https://graph.microsoft.com/v1.0/me/calendar/events");
                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + MasterTenantInformation.TenantAccessToken);

                bool bValidDate = true;
                string sStartDateForGraphAPI = string.Empty;
                string sEndDateForGraphAPI = string.Empty;

                // To validate the Date and value

                if (sStartDateTime.Length > 8)
                {
                    HelperStringToDateInfo StartDateForGraph = new HelperStringToDateInfo(sStartDateTime);

                    if (StartDateForGraph.sYear.Length == 0)
                    {
                        bValidDate = false;
                    }
                    else
                    {
                        //"2020-07-17T08:00:00" -- format
                        sStartDateForGraphAPI = StartDateForGraph.sYear + "-" + StartDateForGraph.sMonth + "-" + StartDateForGraph.sDay + "T" +
                            StartDateForGraph.sHour + ":" + StartDateForGraph.sMinutes + ":" + StartDateForGraph.sSecond;
                    }

                }
                if (sEndDateTime.Length > 8)
                {

                    HelperStringToDateInfo EndDateForGraph = new HelperStringToDateInfo(sEndDateTime);

                    if (EndDateForGraph.sYear.Length == 0)
                    {
                        bValidDate = false;
                    }
                    else
                    {
                         //"2020-07-13T20:30:34.2444915-07:00" - format
                        sEndDateForGraphAPI = EndDateForGraph.sYear + "-" + EndDateForGraph.sMonth + "-" + EndDateForGraph.sDay + "T" +
                          EndDateForGraph.sHour + ":" + EndDateForGraph.sMinutes + ":" + EndDateForGraph.sSecond;
                    }
                }

                if (sStartDateForGraphAPI.Length > 8)
                {
                    sStartDateTime = sStartDateForGraphAPI;
                }
                else
                {
                    sStartDateTime = "2020-07-25T20:30:34.2444915-07:00"; //unreachable code
                }

                if (sEndDateForGraphAPI.Length > 8)
                {
                    sEndDateTime = sEndDateForGraphAPI;
                }
                else
                {
                    sEndDateTime = "2020-07-25T23:00:34.2464912-07:00"; //unreachable code
                }

              
                string sBody = "Please join the meeting, The purpose of this meeting to have discussion.";

                //  sStartDateTime = DateTimeOffset.ParseExact(sStartDateTime, @"MM/dd/yyyy hh:mm:ss", System.Globalization.CultureInfo.InvariantCulture).ToString();
                // sEndDateTime = DateTimeOffset.ParseExact(sEndDateTime, @"MM/dd/yyyy hh:mm:ss", System.Globalization.CultureInfo.InvariantCulture).ToString();

                if (sTimeZone.Length < 2)
                {
                    sTimeZone = "Pacific Standard Time";
                }

                if (bValidDate)
                {

                    string content = @"{
                                  'subject': '" + sSubjectOftheMeeting +
                                  "','body': {'contentType': 'HTML','content': '" + sBody + "'}," +
                                  "'start': {'dateTime': '" + sStartDateTime + "','timeZone': '" + sTimeZone + "'}," +
                                  "'end': { 'dateTime': '" + sEndDateTime + "','timeZone': '" + sTimeZone + "'}," +
                                  "'location':{'displayName':'Teams Online'},'attendees': [{ 'emailAddress': {'address':'" + sAttendees + "','name': ''}" +
                                  ",'type': 'required'}, " +
                                  "{'emailAddress': {'address':'" + sOrganizer + "','name': ''}, 'type': 'required'}]," +
                                  "'isOnlineMeeting': 'true','onlineMeetingProvider': 'teamsForBusiness', 'isOrganizer' : 'true'," +
                                  "'onlineMeetingUrl' : 'https://test.com', 'organizer' : {'emailAddress':{'address':'" + sOrganizer + "','name': ''}" +
                                  " }" +
                                  "}";

                    var httpContent = new StringContent(content, Encoding.GetEncoding("utf-8"), "application/json");

                    var httpResponse = httpClient.PostAsync(url, httpContent).Result;

                    var data = await httpResponse.Content.ReadAsStringAsync();
                    var sEventResponseObject = JsonConvert.DeserializeObject<Event>(data);

                    if (sEventResponseObject != null)
                    {
                        HelperOutputInformation.MeetingWebURL = sEventResponseObject.OnlineMeeting.JoinUrl;
                        sFound = sEventResponseObject.OnlineMeeting.JoinUrl;
                    }
                }
                return sFound;
            }
            catch (Exception cExp)
            {
                string sMessage = "CreateEventCalendarForUser() Error: " + cExp.Message;
                return sMessage;
            }
        }
    }
}