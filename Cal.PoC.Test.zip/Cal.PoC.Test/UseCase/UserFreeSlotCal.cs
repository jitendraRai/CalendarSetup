﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Graph;
using Microsoft.Identity.Client;
using System.Linq;
using Microsoft.Graph.Extensions;

namespace Cal.PoC.Test
{
    //Requirement #2:- Find the available slot for the given date/time with all users who is going to participate in the meeting.
    public class UserFreeSlotCal
    {
        public static async Task<string> GetFreeTimesForUsers(string sUserEmail, string sUserAttendee, string sStartDateTime, string sEndDateTime, string sTimeZone)
        {
            try
            {
                string sFoundAvailableTime = string.Empty;
                string url = string.Format("https://graph.microsoft.com/v1.0/me/findMeetingTimes");

                var httpClient = new HttpClient();
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + MasterTenantInformation.TenantAccessToken);
                string sStartDateForGraphAPI = string.Empty;
                string sEndDateForGraphAPI = string.Empty;

                bool bValidDate = true;
                string sMeetingDuration = "PT1H";  //'meetingDuration': 'PT1H'
                int iStartHour = 0;
                int iStartMinutes = 0;
                int iEndHour = 0;
                int iEndMinutes = 0;

                // To validate the Date and value

                if (sStartDateTime.Length > 8)
                {
                    HelperStringToDateInfo StartDateForGraph = new HelperStringToDateInfo(sStartDateTime);

                    if (StartDateForGraph.sYear.Length == 0)
                    {
                        bValidDate = false;
                    }
                    else
                    {
                        //"2020-07-17T08:00:00"
                        sStartDateForGraphAPI = StartDateForGraph.sYear + "-" + StartDateForGraph.sMonth + "-" + StartDateForGraph.sDay + "T08:00:00";

                        iStartHour = Int32.Parse(StartDateForGraph.sHour);
                        iStartMinutes = Int32.Parse(StartDateForGraph.sMinutes);
                    }

                }
                if (sEndDateTime.Length > 8)
                {

                    HelperStringToDateInfo EndDateForGraph = new HelperStringToDateInfo(sEndDateTime);

                    if (EndDateForGraph.sYear.Length == 0)
                    {
                        bValidDate = false;
                    }
                    else
                    {
                        //"2020-07-17T08:00:00"; //"2020-07-13T20:30:34.2444915-07:00"
                        sEndDateForGraphAPI = EndDateForGraph.sYear + "-" + EndDateForGraph.sMonth + "-" + EndDateForGraph.sDay + "T17:00:00";

                        iEndHour = Int32.Parse(EndDateForGraph.sHour);
                        iEndMinutes = Int32.Parse(EndDateForGraph.sMinutes);
                    }
                }

                //Calcuate the meeting Duration.
                int iDiffHours = 0;
                int iDiffMinutes = 0;

                if ((iStartHour > 0) && (iEndHour > 0))
                {
                    iDiffHours = iEndHour - iStartHour;
                }

                if ((iStartMinutes > 0) && (iEndMinutes > 0))
                {
                    iDiffMinutes = iEndMinutes - iStartMinutes;
                }

                //Calcualate the meetingduration
                if (iDiffHours > 1)
                {
                    if (iDiffMinutes > 29) //consider 30 minutes
                    {
                        // for example, 2 hours and 30 minutes would be 'PT2H30M'. 
                        sMeetingDuration = "PT" + iDiffHours.ToString() + "H" + iDiffMinutes.ToString() + "M";
                    }
                    else
                    {
                        //ignore mintues
                        sMeetingDuration = "PT" + iDiffHours.ToString() + "H";
                    }
                }
                else
                {
                    //Default is 30 minutes.
                    sMeetingDuration = "PT0H30M";
                }


                if (sStartDateForGraphAPI.Length > 8)
                {
                    sStartDateTime = sStartDateForGraphAPI;
                }
                else
                {
                    sStartDateTime = "2020-07-17T08:00:00"; //unreachable code
                }

                if (sEndDateForGraphAPI.Length > 8)
                {
                    sEndDateTime = sEndDateForGraphAPI;
                }
                else
                {
                    sEndDateTime = "2020-07-17T17:00:00"; //unreachable code
                }


                if (sTimeZone.Length < 2)
                {
                    sTimeZone = "Pacific Standard Time";
                }

                if (bValidDate)
                {
                    string content = @"{ 'attendees': [{'emailAddress': {'address':'" + sUserAttendee + "', 'name': ''},'type': 'required'}," +
                        "{ 'emailAddress': {'address':'" + sUserEmail + "','name': ''}, 'type': 'required' } ], " +
                        " 'timeConstraint': {'activityDomain':'work', 'timeSlots': [  { 'start': {  'dateTime': '" + sStartDateTime + "','timeZone': '" + sTimeZone + "' }, " +
                        " 'end': { 'dateTime': '" + sEndDateTime + "',  'timeZone': '" + sTimeZone + "' } }  ] }, " +
                        " 'isOrganizerOptional': 'true', 'meetingDuration': '" + sMeetingDuration + "','returnSuggestionReasons': 'true','minimumAttendeePercentage': '100'}";



                    var httpContent = new StringContent(content, Encoding.GetEncoding("utf-8"), "application/json");

                    var httpResponse = httpClient.PostAsync(url, httpContent).Result;

                    var data = await httpResponse.Content.ReadAsStringAsync();

                    var sMeetingTimesSuggestedObjectData = JsonConvert.DeserializeObject<MeetingTimeSuggestionsResult>(data);


                    //Received SuggestedInformation for the current valid user.

                    //1. MeetingTimeSuggesationResult-->MeetingTimeSuggesations-->MeetingTimeSuggesation-->meetingTimeSlot-->start/end with confidence 

                    bool bFoundAvailableTime = false;

                    if (sMeetingTimesSuggestedObjectData.MeetingTimeSuggestions != null)
                    {
                        foreach (MeetingTimeSuggestion omeetingsug in sMeetingTimesSuggestedObjectData.MeetingTimeSuggestions)
                        {
                            string StartOfficeHours = "08";
                            string EndOfficeHours = "17";

                            bool validhours = true;
                            //First available time.
                            if (omeetingsug.Confidence == 100.0)
                            {
                                //
                                HelperStringToDateInfo SlotStartDateForGraph = new HelperStringToDateInfo(omeetingsug.MeetingTimeSlot.Start.DateTime);
                                HelperStringToDateInfo SlotEndDateForGraph = new HelperStringToDateInfo(omeetingsug.MeetingTimeSlot.End.DateTime);

                               //Known Issue : returns only five records.

                             /*   if  ((Int32.Parse(SlotStartDateForGraph.sHour) > Int32.Parse(StartOfficeHours)) &&
                                    (Int32.Parse(SlotEndDateForGraph.sHour) < Int32.Parse(EndOfficeHours)))
                                {*/

                                    string dtStrFinalStartTime = omeetingsug.MeetingTimeSlot.Start.DateTime;
                                    string dtStrFinalEndTime = omeetingsug.MeetingTimeSlot.End.DateTime;

                                    bFoundAvailableTime = true;

                                    if (dtStrFinalStartTime.Length > 8) //2020-07-17T08:00:00
                                    {
                                        HelperOutputInformation.FinalStartDateTime = dtStrFinalStartTime.ToString();
                                    }

                                    if (dtStrFinalEndTime.Length > 8) //2020-07-17T08:00:00
                                    {
                                        HelperOutputInformation.FinalEndDateTime = dtStrFinalEndTime.ToString();
                                    }

                                    break; //discontinue because found the first available.
                              //  }
                            }
                        }
                        // Valid time is here.
                        if (bFoundAvailableTime)
                        {
                            sFoundAvailableTime = "Available Time is Start Time : " + HelperOutputInformation.FinalStartDateTime + "  End Time : " + HelperOutputInformation.FinalEndDateTime;
                        }
                    }

                    return sFoundAvailableTime;
                }
                else
                {
                    return string.Empty;
                }

             }
            catch (Exception cExp)
            {
                string sMessage = "GetFreeTimesForUsers(): Error: " + cExp.Message;
                return sMessage;
            }
        }
    }
}
