using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Text;
using System.Net;
using System.Collections.Generic;


/*
 * This is for the POC to create meeting request. 
 * 
 * 
 */
namespace Cal.PoC.Test
{
    public static class MainCalCreateFunction
    {
        [FunctionName("POCCalCreateFunction")]

        public static async Task<HttpResponseMessage> Run(
           [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequest req,
           ILogger log, ExecutionContext context)

        {
            log.LogInformation("C# HTTP trigger function POCCalFunction processed started.");

            var config = new ConfigurationBuilder()
                   .SetBasePath(context.FunctionAppDirectory)
                   .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                   .AddEnvironmentVariables()
                   .Build();
        
            

            //Read the data.
            if (req != null)
            {
                HelperInputTenantInformation InputInfo = await BuildJobInfo(req);
               

                log.LogInformation("read config completed...");

                bool bValidDate = true;

                // To validate the Date and value

                if (InputInfo.StartDateTime.Length > 8)
                {
                    InputInfo.StartDateForGraph = new HelperStringToDateInfo(InputInfo.StartDateTime);

                    if (InputInfo.StartDateForGraph.sYear.Length == 0)
                    {
                        bValidDate = false;
                    }

                }
                if (InputInfo.EndDateTime.Length > 8)
                {

                    InputInfo.EndDateForGraph = new HelperStringToDateInfo(InputInfo.EndDateTime);

                    if (InputInfo.EndDateForGraph.sYear.Length == 0)
                    {
                        bValidDate = false;
                    }
                }

                if ((InputInfo.MeetingAttendees.Length > 0) && (bValidDate == true))
                {
                    //Validate the email id format

                    //Call Grpah API
                    
                    MasterTenantInformation.ClientOrApplicationID = config["ClientOrApplicationID"];

                    MasterTenantInformation.ClientSeceretID = config["ClientSeceretID"];
                    log.LogInformation("MasterTenantInformation.ClientSeceretID " + config["ClientSeceretID"]);

                    MasterTenantInformation.TenantID = config["TenantID"];
                    log.LogInformation("MasterTenantInformation.TenantID  " + config["TenantID"]);

                    MasterTenantInformation.TenantAuthority = config["TenantAuthority"] + MasterTenantInformation.TenantID + " /";
                    log.LogInformation("MasterTenantInformation.TenantAuthority " + config["TenantAuthority"]);

                    MasterTenantInformation.TenantGrpahURL = config["TenantGrpahURL"];
                    log.LogInformation(" MasterTenantInformation.TenantGrpahURL " + config["TenantGrpahURL"]);

                    MasterTenantInformation.ServiceUserName = config["ServiceUserName"];
                    log.LogInformation("MasterTenantInformation.ServiceUserName " + config["ServiceUserName"]);

                    MasterTenantInformation.ServiceCredential = config["ServiceCredential"];
                    log.LogInformation("MasterTenantInformation.ServiceCredential  xxxxxx" + config["ServiceCredential"] +"yyddtd");


                    /* MasterTenantInformation.ClientOrApplicationID = "958ea682-b8d9-439f-b14a-93496089fb74";
                     MasterTenantInformation.ClientSeceretID = "n_.S~~LwA53vXNrUlgk-n_.z7Pu564~CfO";
                     MasterTenantInformation.TenantID = "50d1fc03-3b02-4dbf-a267-764d56e1dfd4";
                     MasterTenantInformation.TenantAuthority = "https://login.microsoftonline.com/" + MasterTenantInformation.TenantID + "/";
                     MasterTenantInformation.TenantGrpahURL = "https://graph.microsoft.com/.default";*/

                    try
                    {
                        log.LogInformation("HelperTokenRetrieve.LoadTokenFromMSGraphClient function started ");
                        MasterTenantInformation.TenantAccessToken = HelperTokenRetrieve.LoadTokenForMSGraphClient().GetAwaiter().GetResult();
                        log.LogInformation("HelperTokenRetrieve.LoadTokenFromMSGraphClient function end ");

                        log.LogInformation("sToken : " + MasterTenantInformation.TenantAccessToken);

                        log.LogInformation("HelperTokenRetrieve.LoadTokenfromOffice365 function started ");
                        string sToken = HelperTokenRetrieve.LoadTokenfromOffice365().GetAwaiter().GetResult();
                        log.LogInformation("HelperTokenRetrieve.LoadTokenfromOffice365 function end ");

                        log.LogInformation("sToken : " + MasterTenantInformation.TenantAccessToken);

                        if (MasterTenantInformation.TenantAccessToken.Length > 0)
                        {
                            //Call Graph API functions
                            bool bValidUsers = true;

                            string sUserFoundinAD = ValidateUsersExist.IsValidUser(InputInfo.MeetingAttendees).GetAwaiter().GetResult();

                            if (sUserFoundinAD.Length > 0)
                            {
                                log.LogInformation(InputInfo.MeetingAttendees + " Users Attendee does exist in Active Directory and Display name : " + sUserFoundinAD);
                                HelperOutputInformation.MeetingAttendees = InputInfo.MeetingAttendees;
                            }
                            else
                            {
                                log.LogInformation(InputInfo.MeetingAttendees + " Users Attendee does not exist in Active Directory ");
                                bValidUsers = false;
                            }

                            sUserFoundinAD = ValidateUsersExist.IsValidUser(InputInfo.MeetingOrganizer).GetAwaiter().GetResult();

                            if (sUserFoundinAD.Length > 0)
                            {
                                HelperOutputInformation.MeetingOrganizer = InputInfo.MeetingOrganizer;
                                log.LogInformation(InputInfo.MeetingOrganizer + " Users Organizer does exist in Active Directory and Display Name :" + sUserFoundinAD);
                            }
                            else
                            {
                                log.LogInformation(InputInfo.MeetingOrganizer + " Users Organizer does not exist in Active Directory");
                                bValidUsers = false;
                            }
                            //Validate the existance of these users in AD
                            if (bValidUsers)
                            {
                                  bool bValidSlot = true;

                                  string sFoundAttendeesTime = GetScheduleInfoForTime.GetScheduleForUser(InputInfo.MeetingAttendees, InputInfo.StartDateTime, InputInfo.EndDateTime, InputInfo.TimeZone).GetAwaiter().GetResult();

                                    if (sFoundAttendeesTime != null)
                                    {
                                         HelperOutputInformation.FinalStartDateTime = InputInfo.StartDateTime;
                                         HelperOutputInformation.FinalEndDateTime = InputInfo.EndDateTime;

                                    log.LogInformation(InputInfo.MeetingAttendees + " Attendee User has the free slot ");
                                    }
                                    else
                                    {
                                        log.LogInformation(InputInfo.MeetingAttendees + " Attendee User does not has the free slot ");
                                        bValidSlot = false;
                                    }


                                    string sFoundOrganizerTime = GetScheduleInfoForTime.GetScheduleForUser(InputInfo.MeetingOrganizer, InputInfo.StartDateTime, InputInfo.EndDateTime, InputInfo.TimeZone).GetAwaiter().GetResult();

                                    if (sFoundOrganizerTime != null)
                                    {
                                            HelperOutputInformation.FinalStartDateTime = InputInfo.StartDateTime;
                                            HelperOutputInformation.FinalEndDateTime = InputInfo.EndDateTime;
                                    log.LogInformation(InputInfo.MeetingOrganizer + " Organizer User has  the free slot");
                                    }
                                    else
                                    {
                                        log.LogInformation(InputInfo.MeetingOrganizer + " Organizer User does not hase  the free slot");
                                        bValidSlot = false;
                                    }



                                    if (bValidSlot == false)
                                    {
                                        string sFoundFreeTime = UserFreeSlotCal.GetFreeTimesForUsers(InputInfo.MeetingOrganizer, InputInfo.MeetingAttendees,
                                        InputInfo.StartDateTime, InputInfo.EndDateTime, InputInfo.TimeZone).GetAwaiter().GetResult();

                                        if (sFoundFreeTime != null)
                                        {
                                            log.LogInformation(InputInfo.MeetingAttendees + " UserFreeSlotCal.GetFreeTimesForUsers Attendee User has the free slot and time slot is " + sFoundFreeTime);


                                                //Update the startTime and EndTime as per available freeslot date/time
                                                if ((HelperOutputInformation.FinalStartDateTime != null) && (HelperOutputInformation.FinalEndDateTime != null))
                                                 {
                                                    InputInfo.StartDateTime = HelperOutputInformation.FinalStartDateTime;
                                                    InputInfo.EndDateTime = HelperOutputInformation.FinalEndDateTime;
                                                }
                                        }
                                        else
                                        {
                                            log.LogInformation(" Valid Free Slot Issue:- Please provide the valid input to the C# HTTP trigger function" +
                                                " POCCalFunction to get the valid Free Slot. Input should be in JSON format.  Please refer documentation.");
                                            log.LogInformation(InputInfo.MeetingAttendees + " UserFreeSlotCal.GetFreeTimesForUsers Attendee User does not has the free slot ");
                                        }

                                    }
                                    else
                                    { //Do nothing;;;
                                    }

                                 //Create meeting request
                                string sFoundCal = CreateMeetingInviteCal.CreateMeetingForUser(InputInfo.MeetingAttendees, InputInfo.MeetingOrganizer
                                        , InputInfo.SubjectOftheMeeting, InputInfo.StartDateTime, InputInfo.EndDateTime).GetAwaiter().GetResult();

                                    if (sFoundCal != null)
                                    {
                                        log.LogInformation(InputInfo.MeetingOrganizer + " - Organizer and " + InputInfo.MeetingAttendees + " " +
                                            "- Attendee are ready for the meeting and invitation will be send. ");


                                        string sFoundEvent = CreateEventCalendar.CreateEventCalendarForUser(InputInfo.MeetingAttendees, InputInfo.MeetingOrganizer
                                        , InputInfo.SubjectOftheMeeting, InputInfo.StartDateTime, InputInfo.EndDateTime, InputInfo.TimeZone).GetAwaiter().GetResult();


                                        if (sFoundEvent != null)
                                        {
                                            log.LogInformation(InputInfo.MeetingOrganizer + " - Organizer and " + InputInfo.MeetingAttendees + " " +
                                                "- Attendee are ready for the meeting and invitation sent. ");
                                        }
                                        else
                                        {
                                            log.LogInformation("Calendar event creation has the issue: -Please provide the valid input to the C# HTTP trigger function" +
                                            " POCCalFunction to get the valid Free Slot. Input should be in JSON format.  Please refer documentation.");
                                        }
                                    }
                                    else
                                    {
                                        log.LogInformation("Online meeting creation has the issue: -Please provide the valid input to the C# HTTP trigger function" +
                                        " POCCalFunction to get the valid Free Slot. Input should be in JSON format.  Please refer documentation.");

                                    }
                                
                                }  // valid users
                                else
                                {

                                    log.LogInformation(" Valid User Issue:- Please provide the valid input to the C# HTTP trigger function POCCalFunction" +
                                        " to get the Valid users. Input should be in JSON format.  Please refer documentation.");
                                } 

                            } // valid token issue
                            else
                            {

                                log.LogInformation(" Valid Token Issue:- Please provide the valid input to the C# HTTP trigger function POCCalFunction" +
                                    " to get the Authentication/Token. Input should be in JSON format.  Please refer documentation.");
                            }
                    }
                    catch (Exception cExp)
                    {
                        string sMessage = cExp.Message + "" + cExp.InnerException;
                        log.LogError("C# HTTP trigger function POCCalFunction has errors and please find message here ::: ." + sMessage);
                    }
                }
                else
                {
                    log.LogInformation(" Please provide the valid input or DateTime format to the C# HTTP trigger function POCCalFunction. Input should be in JSON format. Please refer documentation.");

                }

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                dynamic data = JsonConvert.DeserializeObject(requestBody);
                InputInfo.MeetingAttendees = InputInfo.MeetingAttendees ?? data?.AttendeeName;

                string responseMessage = string.IsNullOrEmpty(InputInfo.MeetingAttendees)
                    ? "This HTTP triggered function executed successfully."
                    : $"Hello, {InputInfo.MeetingAttendees }. This HTTP triggered function POC Cal Idx executed successfully.";

                log.LogInformation(responseMessage);

               string strMeetingOrganizer = HelperOutputInformation.MeetingOrganizer;
               string strMeetingAttendees = HelperOutputInformation.MeetingAttendees;
               string strFinalStartDateTime = HelperOutputInformation.FinalStartDateTime;
               string strFinalEndDateTime = HelperOutputInformation.FinalEndDateTime;
               string strSubjectOftheMeeting = HelperOutputInformation.SubjectOftheMeeting;
               string strMeetingWebURL = HelperOutputInformation.MeetingWebURL;


                var DataForEndUserFunction = new {
                                        MeetingOrganizer = strMeetingOrganizer,
                                        MeetingAttendees = strMeetingAttendees,
                                        FinalStartDateTime= strFinalStartDateTime,
                                        FinalEndDateTime = strFinalEndDateTime,
                                        SubjectOftheMeeting = strSubjectOftheMeeting,
                                        MeetingWebURL = strMeetingWebURL
                                       };

                var jsonDataForSDSFunction = JsonConvert.SerializeObject(DataForEndUserFunction);

                return new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(jsonDataForSDSFunction, Encoding.UTF8, "application/json")
                };
            }
            else
            {
                log.LogInformation("Request Input Error:- Please provide the valid input to the C# HTTP trigger function POCCalFunction. Input should be in JSON format. Please refer documentation.");
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
            }
        }


        private static async Task<HelperInputTenantInformation> BuildJobInfo(HttpRequest req)
        {
            HelperInputTenantInformation InputInfo = null;

            if (req.Body.Length > 0)
            {
                InputInfo = await GetInputDetail(req);
            }
            else
            {
                InputInfo = new HelperInputTenantInformation()
                {
                    MeetingOrganizer = "",
                    MeetingAttendees =  "",
                    StartDateTime =  "",
                    EndDateTime =  "",
                    SubjectOftheMeeting =  "",
                    TimeZone = ""
                };
            }

            return InputInfo;
        }

        private static async Task<HelperInputTenantInformation> GetInputDetail(HttpRequest req)
        {
            HelperInputTenantInformation InputInfo;
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic inputobj = JsonConvert.DeserializeObject(requestBody);
            InputInfo = new HelperInputTenantInformation()
            {
                MeetingOrganizer = inputobj.MeetingOrganizer ?? "",
                MeetingAttendees = inputobj.MeetingAttendees ?? "",
                StartDateTime = inputobj.StartDateTime ?? "",
                EndDateTime = inputobj.EndDateTime ?? "",
                SubjectOftheMeeting = inputobj.SubjectOftheMeeting ?? "",
                TimeZone = inputobj.TimeZone ?? ""
            };

            return InputInfo;
        }
    }

}
