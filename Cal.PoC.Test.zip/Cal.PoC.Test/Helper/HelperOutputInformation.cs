﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cal.PoC.Test
{

    // To provide the response from Azure Function
    public class HelperOutputInformation
    {
        public static string MeetingOrganizer { get; set; }
        public static string MeetingAttendees { get; set; }
        public static string FinalStartDateTime { get; set; }
        public static string FinalEndDateTime { get; set; }
        public static string SubjectOftheMeeting { get; set; }

        public  static string MeetingWebURL { get; set; }

        public static string MeetingTimeZone { get; set; }

        public static string EmailSend { get; set; }

        public static HelperStringToDateInfo FinalStartDateForGraph { get; set; }

        public static HelperStringToDateInfo FinalEndDateForGraph { get; set; }

        public HelperOutputInformation()
        {
            MeetingOrganizer = "";
            MeetingAttendees = "";
            FinalStartDateTime = "";
            FinalEndDateTime = "";
            SubjectOftheMeeting = "";
            MeetingWebURL = "";
            EmailSend = "";
            MeetingTimeZone = "";
        }
        public HelperOutputInformation(string sMeetingOrganizer, string sMeetingAttendees, string sFinalStartDateTime, string sFinalEndDateTime, 
            string sSubjectOftheMeeting, 
             string sMeetingWebURL)
        {
            MeetingOrganizer = sMeetingOrganizer;
            MeetingAttendees = sMeetingAttendees;
            FinalStartDateTime = sFinalStartDateTime;
            FinalEndDateTime = sFinalEndDateTime;
            SubjectOftheMeeting = sSubjectOftheMeeting;
            MeetingWebURL = sMeetingWebURL;
        }

    }
}
