﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Graph;
using Microsoft.Identity.Client;
using System.Net.Http;
using System.Net.Http.Headers;


namespace Cal.PoC.Test
{
    public class MasterTenantInformation
    {
        public static string ClientOrApplicationID { get; set; }
        public static string ClientSeceretID { get; set; }
        public static string TenantID { get; set; }
        public static string TenantAuthority { get; set; }
        public static string TenantGrpahURL { get; set; }
        public static string TenantAccessToken { get; set; }
        public static GraphServiceClient TenantGraphClient { get; set; }

        public static string ServiceUserName { get; set; }

        public static string ServiceCredential { get; set; }

    }

    public class MsalAuthenticationProvider : IAuthenticationProvider
    {
        private IConfidentialClientApplication _clientApplication;
        private string[] _scopes;

        public MsalAuthenticationProvider(IConfidentialClientApplication clientApplication, string[] scopes)
        {
            _clientApplication = clientApplication;
            _scopes = scopes;
        }

        public async Task AuthenticateRequestAsync(HttpRequestMessage request)
        {
            var token = await GetTokenAsync();
            request.Headers.Authorization = new AuthenticationHeaderValue("bearer", token);
        }

        public async Task<string> GetTokenAsync()
        {
            AuthenticationResult authResult = null;
            authResult = await _clientApplication.AcquireTokenForClient(_scopes).ExecuteAsync();
            return authResult.AccessToken;
        }
    }

    public class HelperInputTenantInformation
    {
        public string MeetingOrganizer { get; set; }
        public string MeetingAttendees { get; set; }
        public string StartDateTime { get; set; }

        public HelperStringToDateInfo StartDateForGraph { get; set; }

        public HelperStringToDateInfo EndDateForGraph { get; set; }

        public  string EndDateTime { get; set; }
        public string SubjectOftheMeeting { get; set; }

        public string TimeZone { get; set; }

    }

    public class HelperStringToDateInfo
    {
        public string sYear { get; set; }
        public string sDay { get; set; }

        public string sMonth { get; set; }

        public string sHour { get; set; }

        public string sMinutes { get; set; }

        public string sSecond { get; set; }

        public HelperStringToDateInfo ()
        {
            sYear = "";
            sDay = "";
            sMonth = "";
            sHour = "";
            sMinutes = "";
            sSecond = "";
        }

        public HelperStringToDateInfo(string strDateVal)
        {
            bool bValidDate = false;
            try
            {
                if (strDateVal.Length > 8)
                {
                    DateTime sStartDateTime = DateTime.ParseExact(strDateVal, @"MM/dd/yyyy hh:mm:ss", System.Globalization.CultureInfo.InvariantCulture);

                    if (sStartDateTime != null)
                    {
                        bValidDate = true;
                        sYear = sStartDateTime.Year.ToString();
                        sDay = sStartDateTime.Day.ToString("00");
                        sMonth = sStartDateTime.Month.ToString("00");
                        sHour = sStartDateTime.Hour.ToString("00");
                        sMinutes = sStartDateTime.Minute.ToString("00");
                        sSecond = sStartDateTime.Second.ToString("00");
                    }

                }
            }
            catch (Exception cExp)
            {
                string sMessage = cExp.Message;
                bValidDate = false;
            }

            // set the default date.
            if (bValidDate == false)
            {
                sYear = "";
                sDay = "";
                sMonth = "";
                sHour = "";
                sMinutes = "";
                sSecond = "";
            }
        }
    }
}
