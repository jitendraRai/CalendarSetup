﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Graph;
using Microsoft.Identity.Client;

namespace Cal.PoC.Test
{
    public class HelperTokenRetrieve
    {
        // Get Token based on single sign on App.
        public static async Task<string> LoadTokenForMSGraphClient()
        {
            try
            {
                // Configure app builder
                var app = ConfidentialClientApplicationBuilder
                   .Create(MasterTenantInformation.ClientOrApplicationID)
                   .WithClientSecret(MasterTenantInformation.ClientSeceretID)
                   .WithAuthority(new Uri(MasterTenantInformation.TenantAuthority))
                   .Build();

                var scopes = new[] { MasterTenantInformation.TenantGrpahURL };

                var authenticationProvider = new MsalAuthenticationProvider(app, scopes);
                GraphServiceClient graphClient = new GraphServiceClient(authenticationProvider);

                var graphResult = graphClient.Users.Request().GetAsync().Result;

                var UserName = graphResult[0].Mail.ToString();

                var sToken = authenticationProvider.GetTokenAsync().GetAwaiter().GetResult();

                MasterTenantInformation.TenantGraphClient = graphClient;


                return sToken;
            }
            catch (Exception cExp)
            {
                string sMessage = "LoadTokenForMSGraphClient() Error: " + cExp.Message;
                return sMessage;
            }
        }

        //Get Token based on global service account.
        public static async Task<string> LoadTokenfromOffice365()
        {
            try
            {
                #region Confidential
                string applicationId = MasterTenantInformation.ClientOrApplicationID;
                string clientSecret = MasterTenantInformation.ClientSeceretID;
                string sServiceUserName = MasterTenantInformation.ServiceUserName;
                string sServiceCredential = MasterTenantInformation.ServiceCredential;
                string AuthInstance = MasterTenantInformation.TenantAuthority;
                string scopeGraph = MasterTenantInformation.TenantGrpahURL;
                #endregion


                string authority = string.Format(CultureInfo.InvariantCulture, AuthInstance, MasterTenantInformation.TenantID);


                var client = new HttpClient();
                client.BaseAddress = new Uri(authority);
                var request = new HttpRequestMessage(HttpMethod.Post, "/" + MasterTenantInformation.TenantID + "/oauth2/v2.0/token");

                var byteArray = new UTF8Encoding().GetBytes(applicationId + ":" + clientSecret);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                #region Token FormDate
                    var formData = new List<KeyValuePair<string, string>>();
                    formData.Add(new KeyValuePair<string, string>("grant_type", "password"));
                    formData.Add(new KeyValuePair<string, string>("username", sServiceUserName));
                    formData.Add(new KeyValuePair<string, string>("password", sServiceCredential));
                    formData.Add(new KeyValuePair<string, string>("scope", scopeGraph));
                #endregion

                request.Content = new FormUrlEncodedContent(formData);
                var response = await client.SendAsync(request);
                var bearerData = await response.Content.ReadAsStringAsync();
                var bearerToken = JObject.Parse(bearerData)["access_token"].ToString();

                MasterTenantInformation.TenantAccessToken = bearerToken.ToString();

                return bearerToken.ToString();
            }
            catch (Exception cExp)
            {
                string sMessage = "LoadTokenfromOffice365() : Error: " + cExp.Message;
                return sMessage;
            }

        }

    }
}
